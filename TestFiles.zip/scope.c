int w; /* scope level 0 */
int x;

void f(int a, int b) { /* scope level 1 after f */
  int c;
  c = a + b + x;
  { 
    int b; /* scope level 2 */
    int z;
  }
  { 
    int a; /* scope level 2 */
    int x;
    { 
      int c; /* scope level 3 */
      int x;
      b = a + b + c + w; /* which a, which b */
    }
  }
}
void main(void) { /* scope level 1 after main */
  int xx; 
}

/* no main */
int x;

void f(void) {}


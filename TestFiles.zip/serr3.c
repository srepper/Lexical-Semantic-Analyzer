/* redeclaration of name x in the same scope */
int x;

void x(void) {}

void main(void){}

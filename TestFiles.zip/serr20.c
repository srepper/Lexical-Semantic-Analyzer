/* From Louden page 496*/
/* A program to perform Euclid's
   Algorithm to compute gcd. */
int input(void)
{
	return 0;
}

int gcd (int u, int v)
{ if (v == 0) return u;
  else return gcd(v,u-u/v*v);
  /* u-u/v*v == u mod v */
}

void main(void)
{ int x; int y;
 x = input(); y = input(); 
  gcd(x,y);
}

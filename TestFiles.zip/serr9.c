int y;

void main(void) {/* x is not an array */
  int x;
  x[2] = y;
}

void f(void) {}

void main(void) {/* g is undeclared */
  g();
}

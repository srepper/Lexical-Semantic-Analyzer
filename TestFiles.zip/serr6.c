/* redeclaration of name x in the same scope */

void f(void) { int a; { int x; int x; } }

void main(void){}

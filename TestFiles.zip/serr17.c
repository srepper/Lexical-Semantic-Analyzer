int x;

void f(void) { x = y;} /* y is used before decl */

int y;

void g(void) { x = y; }

void main(void) {}




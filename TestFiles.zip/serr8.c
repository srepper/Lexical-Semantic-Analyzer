int y;

void main(void) {/* x is undeclared */
  x = y;
}

/* redeclaration of name x in the same scope */

void f(int x) { int x; }

void main(void){}

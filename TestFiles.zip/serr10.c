int y;

void main(void) {/* x is not an orinary variable */
  int x[10];
  x = y;
}

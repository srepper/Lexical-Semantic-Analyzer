int y;

void main(void) {/* y is not an array */
  int x;
  x = y[2];
}

int a;
void f(int b) {
  { 
    int c;
    {
      int d;
      {
	int e;
	e = d + c + b + a;
      }
    }
  }
}

void main(void){}

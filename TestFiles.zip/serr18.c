/* multiple semantic errors */
int x;
void f(void) {
  y = x;
  x = a + a + a;
  x[2] = 20;
  g();
}

/*Arithmetic Expressions and Assignment Statement*/

int x; int y; int sum;

void main(void)
{
   x = x - 2; 
   y = y + 3; 
   sum = sum - x - y + 4;
   sum = sum * sum / y;
   

}


void f(int u, int v) {/* JVM nums 0, 1, 2, 3, 4 */
  int w;
  w = u * v;
  { 
    int x;
    x = w - w;
  }

  {
    int y;
    y = u - w + v;
  }
}

void g(int a, int b[]) {/* JVM nums 0, 1, 2, 3, 4 */
  int c;
  c = a * b[2];
  { 
    int d;
    d = c;;
  }

  {
    int e;
    e = b[2+3];
  }
}



void main(void) { 
  int xx; /* JVM of this should be 1 and not 0 */
  int yy; /* JVM of this should be 2 and not 1 */
}

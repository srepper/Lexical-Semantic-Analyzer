void f(int a) {/* should have JVM# 0,1,2,3 each ar different scope */
  { int a; { int a; { int a; }}}
}

void main(void) {}

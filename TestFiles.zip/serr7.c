int x;

void main(void) {/* y is undeclared */
  x = y;
}

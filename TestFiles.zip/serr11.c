int y;

void main(void) {/* y is not a function */
  int x;
  x = y();
}

/*Procedure without any parameter*/

void sum(void)
{
    int n; int x; 
    x = 0;
    while (n <= 10) 
    { 
        x = x + n;
        n = n + 1;
    }
}

void main(void)
{     /*main*/
    sum();
}



/* main not last */
int x;

void f(void) {}

int y;

void main(void) {}

void g(void) {}


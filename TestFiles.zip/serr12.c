int y;

int f(void) {
  return 5;
}

void main(void) {/* f is not an ordinary variable */
  int x;
  f = x;
}

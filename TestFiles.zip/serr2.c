/* redeclaration of name x in the same scope */
int x;
int x[10];

void main(void){}

/* redeclaration of name x in the same scope */
int x;
int x;

void main(void){}

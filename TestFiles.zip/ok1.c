int y;
void f(void) {}
int x;
int f(int x)
{
   int result;
   result = 1;
   return result;
}

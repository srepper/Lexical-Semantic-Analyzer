/* arrays and variables cannot be of type void */
void x;
void y[10];
void main(void) {}

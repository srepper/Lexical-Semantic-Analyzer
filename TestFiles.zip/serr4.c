/* redeclaration of name f in the same scope */

void f(void) {}

int f(void) {}

void main(void){}
